/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,tsx,ts,js,jsx}"],
  theme: {
    extend: {},
  },
  plugins: [],
}